<?php 
/**
 * ggtheme functions and definitions
 *
 */

function add_gg_js() {
	wp_enqueue_script( 'gg_theme_js', get_stylesheet_directory_uri() . '/js/jsFunctions.js', array( 'jquery' ), true );
}
add_action('wp_enqueue_scripts', 'add_gg_js');